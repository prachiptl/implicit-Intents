package prachi.com.implicitintents;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.*;


public class MainActivity extends AppCompatActivity {

    Button mLaunchButton;
    EditText mUri;
    Button mRingButton;
    EditText mNum;
    Button mCloseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLaunchButton = (Button) findViewById(R.id.launchButton);
        mUri = (EditText) findViewById(R.id.textforurl);

        mRingButton = (Button) findViewById(R.id.ringButton);
        mNum = (EditText) findViewById(R.id.textForNum);

        mCloseButton = (Button) findViewById(R.id.closeButton);

        mLaunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(mUri.getText().toString()));
                startActivity(browserIntent);
            }
        });


        mRingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL);
                String p = "tel:" + mNum.getText().toString();
                i.setData(Uri.parse(p));
                startActivity(i);

            }
        });

        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
